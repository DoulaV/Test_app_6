---
name: higgsfield-style
description: >
  Use when the user asks about visual styles, aesthetics, color grades, film looks,
  or how to set the tone and atmosphere of a Higgsfield generation.
user-invocable: true
metadata:
  tags: [higgsfield, style, VHS, cinematic, anamorphic, color, aesthetic]
  version: 3.1.3
  updated: 2026-09-26
  parent: higgsfield
---

# Higgsfield Visual Styles

## Core Platform Styles

These five styles are Higgsfield's named presets. Reference them by exact name.

### Cinematic
**Look:** Polished, high-contrast, vivid colors, balanced exposure — modern blockbuster
**Best for:** Drama, action, narrative films, commercials, any professional content
**Color tendency:** Rich, saturated, clean
**Prompt phrase:** "Style: Cinematic"
**Pair with:** Kling 2.6/3.0, Dolly In, Arc, Crane Up

```
Example: A detective walks through a night market.
Style: Cinematic. Cold blue shadows, warm amber market stall light.
Shallow depth of field. 16:9.
```

---

### VHS
**Look:** Retro videotape grain, color bleed, slight scanlines, analog imperfection
**Best for:** 80s/90s nostalgia, horror, thriller, retro music videos, flashbacks
**Color tendency:** Slightly washed out, warm yellows and reds, low contrast
**Prompt phrase:** "Style: VHS"
**Pair with:** Handheld camera, Wan 2.6 or Wan 2.5 (2.5 is not in the API catalog, 2026-09-26 — verify in the live UI), any horror preset

```
Example: Friends at a house party in 1987.
Style: VHS. Warm, grainy, slightly overexposed. 4:3 ratio.
```

---

### Super 8MM
**Look:** Warm film grain, soft vignette, muted colors, home-movie feel
**Best for:** Personal stories, romance, nostalgia, indie films, family moments
**Color tendency:** Warm, golden, slightly faded
**Prompt phrase:** "Style: Super 8MM"
**Pair with:** Handheld, natural light descriptions, intimate scenes

```
Example: A couple dancing in a sunlit backyard in the 1970s.
Style: Super 8MM. Warm grain, soft vignette edges. 4:3.
```

---

### Anamorphic
**Look:** Ultra-wide aspect ratio (2.35:1), horizontal lens flares, slight barrel distortion,
epic scale — classic Hollywood widescreen
**Best for:** Action, epic fantasy, war films, sweeping landscapes, high drama
**Color tendency:** High contrast, deep blacks, rich highlights
**Prompt phrase:** "Style: Anamorphic" or "Style: Anamorphic, 2.35:1 widescreen"
**Pair with:** Crane Up, 360 Orbit, Super Dolly Out, Seedance 2.0 / Minimax Hailuo 2.3

```
Example: An army marches across a frozen plain at dawn.
Style: Anamorphic, 2.35:1. Deep blue-grey tones. Lens flare on the rising sun.
```

---

### Abstract
**Look:** Non-representational, surreal color schemes, unconventional shapes, artistic
**Best for:** Music videos, conceptual art, dream sequences, experimental content
**Color tendency:** Vivid, unexpected, driven by concept not realism
**Prompt phrase:** "Style: Abstract"
**Pair with:** Wan 2.6 or Wan 2.5 (2.5 is not in the API catalog, 2026-09-26 — verify in the live UI), Portal, Multiverse, Glitch presets

```
Example: Fractured geometric shapes pulse to music in a void.
Style: Abstract. Electric blue and magenta on black. 1:1 ratio.
```

---

## Color Grade Vocabulary

Use these in any prompt regardless of style preset:

| Mood | Color grade description |
|------|------------------------|
| Cold thriller | "Teal and orange, desaturated, high contrast" |
| Warm nostalgia | "Golden hour amber, soft shadows, low contrast" |
| Cyberpunk | "Neon magenta and cyan, deep shadows, HDR" |
| Horror | "Sickly green-yellow, crushed blacks, desaturated" |
| Romance | "Soft warm pink-gold, lifted shadows, dreamy" |
| Documentary | "Neutral, natural light, no grade" |
| Epic fantasy | "Rich jewel tones, deep shadows, volumetric light" |
| Noir | "High contrast black and white, or near-monochrome" |
| Sci-fi cold | "Ice blue and silver, stark white light" |
| Post-apocalyptic | "Desaturated orange and brown, dust haze" |

---

## Lighting Vocabulary

| Type | Description | Best for |
|------|-------------|----------|
| Golden hour | Warm directional light just after sunrise or before sunset | Romantic, epic, beautiful |
| Overcast | Soft diffused light, no shadows | Documentary, emotional, grounded |
| Neon | Colored artificial light from signs/screens | Cyberpunk, night scenes, urban |
| Volumetric | Light rays visible through atmosphere (fog/dust) | Fantasy, cinematic, atmospheric |
| Practical only | All light comes from sources visible in frame (lamps, fire, screens) | Realism, noir, intimate |
| Side-lit | Single strong light from one side creating deep shadow | Drama, tension, portrait |
| Backlit | Subject silhouetted or rimlit from behind | Mystery, romance, epic reveal |
| Low key | Mostly dark with small pools of light | Horror, thriller, noir |
| High key | Bright, even, minimal shadows | Comedy, commercial, lifestyle |

---

## Cinematic Lighting Techniques

Specific lighting setups that AI models respond to well. Use these terms directly
in your prompts for precise control over how light shapes the scene.

| Technique | Effect | Best for |
|-----------|--------|----------|
| Rembrandt lighting | Triangle of light on the shadowed cheek, one eye lit | Portrait drama, character intros, moody interviews |
| Butterfly / Paramount lighting | Overhead light casting a shadow under the nose | Glamour, fashion, beauty shots, classic Hollywood |
| Split lighting | Half the face lit, half in complete shadow | Duality, inner conflict, villain reveals |
| Rim lighting / backlit | Edge glow outlining the subject's silhouette | Mystery, epic reveal, separation from background |
| Motivated lighting | Light source visible or implied in the scene (lamp, window, fire) | Realism, narrative grounding, naturalistic drama |
| Practical lighting | In-scene light sources (neon signs, candles, screens) | Night scenes, cyberpunk, intimate realism |
| Chiaroscuro | Extreme contrast between light and dark areas | Renaissance feel, high drama, painterly compositions |
| High-key | Bright, minimal shadows, even illumination | Comedy, commercial, lifestyle, clean aesthetic |
| Low-key | Deep shadows dominate, small pools of light | Noir, thriller, horror, psychological tension |
| Golden hour / Magic hour | Warm amber directional light, long soft shadows | Romance, beauty, epic landscapes, emotional beats |
| Blue hour | Cool steel-blue ambient light just after sunset | Melancholy, transition, quiet tension, urban solitude |
| Harsh midday sun | Hard overhead light, strong defined shadows | Desert, confrontation, exposed vulnerability |
| Overcast diffused / softbox | Even soft light, no hard shadows | Portraits, documentary, grounded realism |

---

## Aspect Ratio Guide

| Ratio | Name | Best for |
|-------|------|----------|
| 16:9 | Widescreen | Standard video, YouTube, film |
| 9:16 | Vertical | TikTok, Instagram Reels, Shorts |
| 2.35:1 | Anamorphic | Epic cinema, maximum widescreen drama |
| 1:1 | Square | Instagram posts, artistic |
| 4:5 | Portrait | Instagram feed, social portrait |
| 4:3 | Classic TV | Retro, VHS feel, vintage |

---

> **Negative constraints:** For texture/lighting artifacts (flickering textures, style ignored,
> over-lit output, color grade inconsistency) and their prevention phrases, see
> `../shared/negative-constraints.md` — Texture/Lighting Artifacts section.

---

## Style Best Practices (Cinema Studio 3.0 / Seedance 2.0)

These principles apply to Cinema Studio 3.0's generation engine (Business/Team plan only) and complement the style vocabulary above.

### One Style Anchor Rule

ONE primary style anchor beats five adjectives. Beyond 2–3 style tokens, model attention dilutes and the output becomes generic.

**Wrong:** `Style: cinematic, anamorphic, moody, atmospheric, dramatic lighting, film grain, desaturated, noir-inspired, high contrast, vintage feel`

**Right:** `Style: anamorphic, subtle grain, muted palette`

Pick your anchor (the single most important style element), add 1–2 supporting tokens, stop.

### "Cinematic" Does Nothing

Every generated video is "cinematic" by default. The word adds zero information. Replace it with a specific lens or contrast description:

- ~~"cinematic"~~ → `shallow depth of field, warm highlights, cool shadows`
- ~~"cinematic look"~~ → `anamorphic, 2.35:1, horizontal lens flares`
- ~~"cinematic quality"~~ → `35mm film stock, natural grain, Kodak Portra palette`

### Style Transfer via @Reference

Visual style references beat descriptive text. One reference image/video carries more style information than 10 descriptor words:

```
Match the visual style, color grading, and film texture of @Video1.
A woman walks through autumn leaves in a park.
Camera: slow tracking alongside her.
```

Use style references for: color grading, film stock emulation, lighting mood, texture quality, era-specific looks.

### CGI Material Contract

When prompting CGI or product renders, specify 2–4 material properties per surface to avoid the default "plastic sheen":

| Property | Options | Example |
|----------|---------|---------|
| Base | metal, glass, fabric, ceramic, wood, leather | `brushed stainless steel` |
| Roughness | matte, satin, glossy, mirror | `satin finish` |
| Imperfection | scratches, dust, wear, fingerprints, patina | `fine scratches from use` |
| Edge | beveled, sharp, rounded, chamfered | `soft rounded edges` |

**Example:** `A matte ceramic vase with hairline cracks and a subtle patina, soft rounded rim, resting on rough-hewn oak.`

### Period Control

Don't just name the decade — specify the **materials and lighting** of the era:

- ~~"1970s style"~~ → `Kodachrome warm tones, wood paneling, orange shag carpet, tungsten bulbs casting amber light`
- ~~"1940s noir"~~ → `high-contrast black and white, Venetian blind shadows, fedora silhouettes, wet asphalt reflecting streetlamps`
- ~~"1990s home video"~~ → `Hi8 camcorder grain, autofocus hunting, timestamp overlay, oversaturated greens`

---

## Register Poles — the style dial has opposite ends

`[FIELD — 13-project community harvest, 2026-07-18]` — "photoreal cinematic"
is not one register. Production projects sit at *named poles* of a dial, and
the pole decides the whole camera grammar:

| Register pole | Camera grammar | Texture stack |
|---|---|---|
| **Film register** (drama/romance features) | Handheld breathing, off-level allowed, natural motion | 35mm grain, milky low contrast, gate weave, halation, "corners as bright as center" |
| **Broadcast-TV register** (early-2000s drama) | **Locked-off tripod, frontal compositions, held reaction beats, ONE camera move per shot maximum** | Heavy soft diffusion, blooming highlights, telecine grain, flat neutral daytime |
| **Stop-motion / hand-animated** | Stepped motion — "true 12fps, animated on twos: each pose held two frames then snapping, never gliding" + constant painterly boil | **Split-motion rule:** atmosphere (snow, breath-vapor, smoke) moves SMOOTHLY while figures step on twos — an explicit constraint that fights the video model's default smoothness |
| **Anime / cel** | Per-shot named camera, fewer physics/skin blocks (the template contracts) | "Cel-shaded 2D, clean flat fills, two-to-three value cel shading — not painterly, not 3D, no CGI smoothness" |

**The style-anchor slot swaps vocabulary by register.** Same slot, different
language: photoreal anchors on a DP/director look (short-form only — block
prompts describe the look instead, per the seedance measurable-language
rules) · anime anchors on an **art era** ("early 2000s retro anime, vintage
cel proportions") · stop-motion anchors on **medium physics** ("12fps on
twos, painterly boil"). Never carry one register's anchor into another.

**One saturated accent color, reserved for the story.** The corpus-wide
color discipline: the plot-critical prop owns the only saturated accent in a
muted grade (an acid-green device, a chartreuse remote LED) — and the same
reservation works temporally ("golden hour is reserved for the twist";
everything before it stays flat neutral). State the reservation explicitly.

---

## Style Recipes — eight proven shapes

`[OFFICIAL — Higgsfield cinematic-prompt-builder skill, 2026-07]` — starting
recipes, each a distinct render contract. Combine and deviate freely; the
load-bearing part of each is the **is / is-NOT declaration** and the
shots-per-15s shape:

| Recipe | Look declaration | Structure + signature | Audio |
|---|---|---|---|
| **Live-action epic** | 8K photoreal, anamorphic, fine grain — "photoreal, NOT 3D/game" | Oner or multishot; one "hook" event triggers one held slow-mo beat, then snaps back; scale contrast (tiny figures vs vast subject) | Diegetic; slow-mo drops to muffled vacuum + heartbeat, snaps back with a whoosh |
| **3D animated feature** | Vibrant glossy CGI, Pixar-quality stylized, subsurface fur/skin | **6 shots / 15s** montage — "don't use one camera angle"; per-shot spoken lines with delivery described; land a visual gag | Light score allowed; often still SFX-forward |
| **Game cutscene** | UE5 real-time in-engine render — "hyperreal but unmistakably GAME-rendered, NOT film" | 3 shots / 15s, hard cuts; **screen-pinned HUD in a locked accent hex, every element enumerated with exact text** — HUD never parallaxes | No music; SFX + subtle UI ticks |
| **Gameplay footage** | AAA arcade (racing) — hyper-saturated engine render, "in-game, NOT a film plate" | Rock-steady chase-cam locked to vehicle, NO slow-mo anywhere, live HUD (RPM, boost, minimap) | Engine, gears, boost, tyre screech, UI beeps |
| **FPV / POV oner** | One unbroken take, photoreal macro, anamorphic | Beats by timestamp in one paragraph; one named speed ramp (240fps bullet-time beat → snap to 24fps); macro brushes against surfaces | Slow-mo swaps ambience for amplified rhythmic sound |
| **Product / commercial** | 8K editorial, deep black crush, per-section color worlds | 8–10 short sections, hard match-cuts on action; rapid 0.3s macro montage; resolves on a **hero packshot** (product in one third, dark negative space, slow dolly, particle drift, hold) | No music/VO/text — product-handling SFX only |
| **VFX composite** (on a source clip) | Photoreal practical-FX realism; composition + grade INHERITED from the source | INPUT LOCK: plate preserved unchanged, camera inherited exactly; only additions = new element + its light + contact shadows; parallax-locked to an anchor plane | New element's diegetic sounds over preserved room tone |
| **Kaiju / creature** | 8K photoreal anamorphic, ORIGINAL design ("not based on any franchise") | ~6 cuts, per-cut OPTICS; the detail that opens CUT 1 is the one CUT 2 zooms into; **containment rule** ("stays at the sea surface, never airborne") grounds physics and scale | Diegetic only — rumble, roars, water-burst, subsonic boom |

Full engine-side counterparts: the HUD recipe and INPUT LOCK live with
worked patterns in `../higgsfield-seedance/SKILL.md` and
`../higgsfield-seedance-vfx/SKILL.md`; the containment rule doubles as the
build-safe construction law (`../higgsfield-seedance/SKILL.md` § Build-safe
construction).

---

## Related skills
- `higgsfield-camera` — Camera controls to pair with styles
- `higgsfield-mixed-media` — Artistic style overlays (non-photorealistic)
- `higgsfield-moodboard` — Moodboard + Soul Hex for project-level style locking
- `higgsfield-cinema` — Cinema Studio built-in color grading suite
- `templates/` — Annotated genre-specific prompt templates with style examples
