# Template: Top-Down Floor Plan Pre-Visualization

Meta-prompt template for **Claude** (not Seedance). Generates a top-down
floor plan + paste-ready Seedance blocking note in one pass — locks
spatial geometry before any Seedance generation begins.

> **The map is for YOU. The prose is for the model.** The HTML artifact this
> template renders is an authoring aid — you read it, you check the geometry
> against your intent, and what travels into the Seedance prompt is the
> **blocking note**. Never attach the floor plan itself as a reference image.
>
> That is not a style preference, it is the one thing the diagram method is
> agreed on across sources: a staging reference shown to a video model is drawn
> **front-on, from the camera's side, never top-down** — video models think in
> frames, not floor plans, and a floor plan handed to one is geometry it has no
> way to map onto a shot. Top-down is the right shape for *reasoning* about a
> space and the wrong shape for *showing* one. Both facts are true at once, and
> this template lives entirely on the reasoning side.
>
> **The showing side is `staging-reference.md`** — the front-on, colour-coded outline
> drawing that IS attached to the generation, with the three-layer anti-bleed
> architecture under which one house run (record incomplete — a direction, not a rate)
> saw no bleed. Read its measured caveat before promising anyone it will pin positions.

## When to use this template

Any multi-character or geometrically-complex shot where Seedance has
historically picked the wrong spatial reassembly — door-entry shots,
hallway-direction shots, two-character blocking that needs to hold
across cuts. See `../../skills/higgsfield-seedance/FAILURE-MODES.md`
§ Spatial-awareness failures for the failure class this template
prevents.

## Claude prompt template (paste-ready)

```
Build a top-down floor plan for [SCENE]. Mark every character with
their position, which direction they're facing, and who they're
looking at. Include distance between characters and a scale.

Below the diagram, write a paste-ready blocking note for Seedance —
one short paragraph per character covering: where they are, which way
they face, gaze line, pose, what they're touching.

Render as an HTML artifact.

Scene: [DESCRIPTION]
```

Fill `[SCENE]` with the one-line scene title (e.g., "diner standoff").
Fill `[DESCRIPTION]` with the full scene description — characters,
location, action, mood. The richer the description, the better the
spatial reassembly.

## What you get back

- An HTML artifact rendering the top-down floor plan visually
- A paste-ready blocking note formatted for direct copy into the
  Seedance prompt body's Spatial Layout Block (see
  `../../skills/higgsfield-seedance/SUBSKILL.md` § Spatial Layout Block
  for the block structure that consumes this output)

## BAD / GOOD / GREAT

**BAD:** Skipping pre-visualization. Write the Seedance prompt
directly from the scene description; let Seedance pick the spatial
reassembly. Result on multi-character shots: characters end up on the
wrong sides of frame, walk through furniture, face the wrong direction.

**GOOD:** Use this template, get the top-down map, eyeball the
geometry, transcribe the relevant placement into the Seedance prompt
manually. Spatial accuracy improves significantly. The transcription
step introduces errors when geometry is complex.

**GREAT:** Use this template AND paste the blocking note Claude
generates directly into the Seedance prompt's Spatial Layout Block.
Zero transcription. The geometry Claude reasoned about and the
geometry Seedance receives are identical. Iterate the floor plan in
the Claude chat before locking — adjust positions, gaze lines, contact
points until the map matches intent, then copy the blocking note over.

## Locking prop scale to a landmark

The map also locks a prop's **size and position relative to a fixed landmark**,
so a large set-piece stays the same scale take after take. Pin the prop to a
named landmark with an explicit size multiple and a shared sight-line:

```
Mark the fire hydrant. Lock the skydancer to its right — two times a person's
height, standing on the same line as the hydrant.
```

The landmark (hydrant) is something Seedance renders consistently; tying the prop
to it — *2× a person's height, same line* — gives the model a relative anchor
instead of an absolute size it would otherwise re-guess each generation. Use this
for any oversized or position-critical prop (inflatable figures, vehicles,
signage) that must hold scale across cuts.

## See also

- `../../skills/higgsfield-seedance/SUBSKILL.md` § Frame Coordinate System
  — coordinate vocabulary the blocking note uses
- `../../skills/higgsfield-seedance/SUBSKILL.md` § Spatial Layout Block —
  the prompt-body block that consumes the blocking note
- `../../skills/higgsfield-seedance/FAILURE-MODES.md` § Spatial-
  awareness failures — failure class this template prevents
- `multi-character-anchor.md` (sibling template) — paste-ready
  multi-character Seedance prompt that consumes the blocking note
